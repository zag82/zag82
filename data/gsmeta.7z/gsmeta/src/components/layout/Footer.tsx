import React from 'react';

interface Props {}

const Footer = (props: Props) => {
  return (
    <footer className='text-center my-2 smaller'>
      <small>&copy; 2020 Гсс+</small>
    </footer>
  );
};

export default Footer;
