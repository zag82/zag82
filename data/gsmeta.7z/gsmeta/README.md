# gss-file-view

Web based viewer of gslx files

Simple sample application to show web-smeta possibility
